# Free Recall – manuel scoring + løbende analyse

Programmet:
- har frit antal trials
- gemmer hvert trial med det samme
- fortsætter automatisk gennem billedbanken
- har manuel scoring efter hvert trial
- viser automatisk en opdateret analyse efter hvert gemt trial
- læser alle tidligere `*_trials.csv`-filer i `results/`

Analysen viser:
- gennemsnitlig recall
- primacy recall (position 1–5)
- middel recall (position 6–10)
- recency recall (position 11–15)
- primacy effect = primacy recall minus middel recall
- recency effect = recency recall minus middel recall
- 95% konfidensintervaller
- søjlediagram med fejlstænger (95% CI)

Tryk `A` på startskærmen for at åbne analysen når som helst.

Kør:
python3 experiment.py
