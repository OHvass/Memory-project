
import csv
import json
import math
import re
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import simpledialog, messagebox
from PIL import Image, ImageTk

BASE = Path(__file__).resolve().parent
IMGDIR = BASE / "images"
RESDIR = BASE / "results"
PROGRESS = BASE / "image_progress.json"

EXTS = {".jpg", ".jpeg", ".png", ".webp"}
IMAGES_PER_TRIAL = 15
IMAGE_SECONDS = 2.0

def natural_key(s):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", s)]

def label_from_path(p):
    s = re.sub(r"^\d+[_\-\s]*", "", p.stem)
    return re.sub(r"\s+", " ", s.replace("_", " ").replace("-", " ")).strip()

def all_images():
    files = [p for p in IMGDIR.rglob("*") if p.is_file() and p.suffix.lower() in EXTS]
    files.sort(key=lambda p: natural_key(str(p.relative_to(IMGDIR))))
    return files

def get_next_index():
    try:
        return max(0, int(json.loads(PROGRESS.read_text(encoding="utf-8"))["next_image_index"]))
    except Exception:
        return 0

def set_next_index(i):
    PROGRESS.write_text(
        json.dumps({"next_image_index": i}, indent=2),
        encoding="utf-8"
    )

def mean(xs):
    return sum(xs) / len(xs) if xs else float("nan")

def t_critical_95(n):
    # Two-sided 95% t critical value, indexed by sample size n (df=n-1).
    vals = {
        2:12.706,3:4.303,4:3.182,5:2.776,6:2.571,7:2.447,8:2.365,9:2.306,
        10:2.262,11:2.228,12:2.201,13:2.179,14:2.160,15:2.145,16:2.131,
        17:2.120,18:2.110,19:2.101,20:2.093,21:2.086,22:2.080,23:2.074,
        24:2.069,25:2.064,26:2.060,27:2.056,28:2.052,29:2.048,30:2.045
    }
    return vals.get(n, 1.96)

def ci95(xs, clamp=False):
    n = len(xs)
    if n < 2:
        return (float("nan"), float("nan"))
    m = mean(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (n - 1))
    se = sd / math.sqrt(n)
    d = t_critical_95(n) * se
    lo, hi = m - d, m + d
    if clamp:
        lo, hi = max(0, lo), min(1, hi)
    return lo, hi

def pct(x):
    return "—" if math.isnan(x) else f"{100*x:.1f}%"

def ci_text(lo, hi):
    return "—" if math.isnan(lo) or math.isnan(hi) else f"[{100*lo:.1f}%, {100*hi:.1f}%]"

class FreeRecallApp:
    def __init__(self, root):
        self.root = root
        root.title("Free Recall")
        root.configure(bg="white")
        root.attributes("-fullscreen", True)
        root.bind("<Escape>", lambda e: root.attributes("-fullscreen", False))
        root.protocol("WM_DELETE_WINDOW", self.quit_program)

        self.files = all_images()
        if len(self.files) < IMAGES_PER_TRIAL:
            raise RuntimeError(
                f"Fandt kun {len(self.files)} billeder. Der kræves mindst {IMAGES_PER_TRIAL}."
            )

        self.idx = get_next_index()
        if self.idx >= len(self.files):
            self.idx = 0
            set_next_index(0)

        pid = simpledialog.askstring(
            "Deltager-ID", "Indtast deltager-ID (fx P01):", parent=root
        )
        if not pid:
            root.destroy()
            return

        self.pid = re.sub(r"[^A-Za-z0-9_-]+", "_", pid.strip())
        self.session = datetime.now().strftime("%Y%m%d_%H%M%S")

        self.items_file = RESDIR / f"{self.pid}_{self.session}_items.csv"
        self.trials_file = RESDIR / f"{self.pid}_{self.session}_trials.csv"

        with open(self.items_file, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "participant", "session", "trial", "global_image",
                "serial_position", "filename", "label",
                "recalled_manual", "raw_response"
            ])

        with open(self.trials_file, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "participant", "session", "trial",
                "first_global_image", "last_global_image",
                "n_recalled", "recall_rate",
                "primacy_recall", "middle_recall", "recency_recall",
                "primacy_effect", "recency_effect",
                "raw_response"
            ])

        self.trial = 0
        self.current = []
        self.photo = None
        self.score_photos = []
        self.score_vars = []
        self.raw_response = ""
        self.dynamic = []

        self.frame = tk.Frame(root, bg="white")
        self.frame.pack(fill="both", expand=True)

        self.main_text = tk.Label(
            self.frame, bg="white", fg="black",
            font=("Arial", 28), justify="center", wraplength=1150
        )
        self.main_text.pack(expand=True)

        self.image_label = tk.Label(self.frame, bg="white")
        self.image_label.pack(expand=True)

        self.show_menu()

    def clear(self):
        for w in self.dynamic:
            try:
                w.destroy()
            except Exception:
                pass
        self.dynamic = []
        self.main_text.config(text="")
        self.image_label.config(image="")
        self.photo = None

    def show_menu(self):
        self.clear()
        self.root.unbind("<space>")
        self.root.unbind("a")
        self.root.unbind("A")

        if len(self.files) - self.idx < IMAGES_PER_TRIAL:
            self.main_text.config(
                text="Der er færre end 15 ubrugt billeder tilbage.\n\n"
                     "Tilføj flere billeder for at fortsætte."
            )
            return

        n = len(self.load_all_trials())
        self.main_text.config(
            text=(
                "Tryk MELLEMRUM for næste trial.\n\n"
                f"Gemte trials i analysen: {n}\n"
                "Tryk A for at se den løbende analyse.\n\n"
                "Du kan lukke programmet mellem trials, når du vil."
            )
        )
        self.root.bind("<space>", self.start_trial)
        self.root.bind("a", self.show_analysis)
        self.root.bind("A", self.show_analysis)

    def start_trial(self, event=None):
        self.root.unbind("<space>")
        self.root.unbind("a")
        self.root.unbind("A")

        if len(self.files) - self.idx < IMAGES_PER_TRIAL:
            self.show_menu()
            return

        self.trial += 1
        self.current = self.files[self.idx:self.idx + IMAGES_PER_TRIAL]
        self.pos = -1
        self.clear()
        self.show_next_image()

    def show_next_image(self):
        self.pos += 1
        if self.pos >= IMAGES_PER_TRIAL:
            self.show_recall()
            return

        im = Image.open(self.current[self.pos]).convert("RGB")
        im.thumbnail((900, 650))
        self.photo = ImageTk.PhotoImage(im)
        self.image_label.config(image=self.photo)
        self.root.after(int(IMAGE_SECONDS * 1000), self.show_next_image)

    def show_recall(self):
        self.clear()
        self.main_text.config(
            text="Skriv alle de ting, du kan huske.\n"
                 "Rækkefølgen er ligegyldig. Adskil svar med komma."
        )

        entry = tk.Text(self.frame, height=6, width=70, font=("Arial", 20), wrap="word")
        entry.pack(pady=20)
        entry.focus_set()

        button = tk.Button(
            self.frame, text="Fortsæt til scoring",
            font=("Arial", 18),
            command=lambda: self.show_scoring(entry)
        )
        button.pack(pady=10)
        self.dynamic = [entry, button]

    def show_scoring(self, entry):
        self.raw_response = entry.get("1.0", "end").strip()
        self.clear()
        self.score_vars = []
        self.score_photos = []

        top = tk.Frame(self.frame, bg="white")
        top.pack(fill="x", padx=20, pady=(8, 4))
        self.dynamic.append(top)

        tk.Label(
            top, text="Manuel scoring",
            font=("Arial", 22, "bold"), bg="white"
        ).pack()

        tk.Label(
            top,
            text=(
                "Markér de billeder, som deltageren faktisk huskede. "
                "Et svar må gerne være på dansk, et synonym eller en beskrivelse."
            ),
            font=("Arial", 14), bg="white",
            wraplength=1100, justify="center"
        ).pack(pady=(4, 6))

        tk.Label(
            top,
            text=f'Deltagerens svar: "{self.raw_response}"',
            font=("Arial", 13), bg="#f2f2f2",
            wraplength=1100, justify="left",
            padx=10, pady=7
        ).pack(fill="x", padx=20, pady=(0, 6))

        grid = tk.Frame(self.frame, bg="white")
        grid.pack(fill="both", expand=True, padx=15)
        self.dynamic.append(grid)

        for i, p in enumerate(self.current):
            r, c = divmod(i, 5)
            grid.grid_columnconfigure(c, weight=1)
            grid.grid_rowconfigure(r, weight=1)

            cell = tk.Frame(grid, bg="white", bd=1, relief="solid")
            cell.grid(row=r, column=c, padx=4, pady=4, sticky="nsew")

            im = Image.open(p).convert("RGB")
            im.thumbnail((150, 100))
            ph = ImageTk.PhotoImage(im)
            self.score_photos.append(ph)

            pic = tk.Label(cell, image=ph, bg="white")
            pic.pack(pady=(4, 2))

            tk.Label(
                cell, text=label_from_path(p),
                font=("Arial", 10), bg="white", wraplength=160
            ).pack()

            var = tk.BooleanVar(value=False)
            self.score_vars.append(var)

            cb = tk.Checkbutton(
                cell, text="Husket", variable=var,
                font=("Arial", 11), bg="white",
                activebackground="white"
            )
            cb.pack(pady=(1, 4))

            pic.bind("<Button-1>", lambda e, v=var: v.set(not v.get()))

        save_btn = tk.Button(
            self.frame, text="Gem scoring",
            font=("Arial", 16), command=self.save_scoring
        )
        save_btn.pack(pady=8)
        self.dynamic.append(save_btn)

    def save_scoring(self):
        selected = [1 if v.get() else 0 for v in self.score_vars]

        primacy = sum(selected[:5]) / 5
        middle = sum(selected[5:10]) / 5
        recency = sum(selected[10:15]) / 5
        overall = sum(selected) / 15

        primacy_effect = primacy - middle
        recency_effect = recency - middle

        item_rows = []
        for pos, (p, rec) in enumerate(zip(self.current, selected), start=1):
            item_rows.append([
                self.pid, self.session, self.trial,
                self.idx + pos, pos, p.name, label_from_path(p),
                rec, self.raw_response.replace("\n", " | ")
            ])

        with open(self.items_file, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows(item_rows)

        with open(self.trials_file, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                self.pid, self.session, self.trial,
                self.idx + 1, self.idx + IMAGES_PER_TRIAL,
                sum(selected), overall,
                primacy, middle, recency,
                primacy_effect, recency_effect,
                self.raw_response.replace("\n", " | ")
            ])

        # Markér først billederne som brugt efter både svar og manuel scoring er gemt.
        self.idx += IMAGES_PER_TRIAL
        set_next_index(self.idx)

        # Analysen vises automatisk efter hvert nyt trial.
        self.show_analysis()

    def load_all_trials(self):
        rows = []
        for fp in RESDIR.glob("*_trials.csv"):
            try:
                with open(fp, newline="", encoding="utf-8") as f:
                    for row in csv.DictReader(f):
                        try:
                            overall = float(row["recall_rate"])

                            # New column names:
                            if "primacy_recall" in row:
                                primacy = float(row["primacy_recall"])
                                middle = float(row["middle_recall"])
                                recency = float(row["recency_recall"])
                            else:
                                # Compatibility with older program versions.
                                primacy = float(row.get("primacy_rate", 0))
                                middle = float(row.get("middle_rate", 0))
                                recency = float(row.get("recency_rate", 0))

                            pe = float(row.get("primacy_effect", primacy - middle) or (primacy - middle))
                            reff = float(row.get("recency_effect", recency - middle) or (recency - middle))

                            rows.append({
                                "overall": overall,
                                "primacy": primacy,
                                "middle": middle,
                                "recency": recency,
                                "primacy_effect": pe,
                                "recency_effect": reff
                            })
                        except Exception:
                            pass
            except Exception:
                pass
        return rows

    def show_analysis(self, event=None):
        self.root.unbind("<space>")
        self.root.unbind("a")
        self.root.unbind("A")
        self.clear()

        rows = self.load_all_trials()
        if not rows:
            self.main_text.config(
                text="Ingen gemte trials endnu.\n\nTryk MELLEMRUM for at gå tilbage."
            )
            self.root.bind("<space>", lambda e: self.show_menu())
            return

        panel = tk.Frame(self.frame, bg="white")
        panel.pack(fill="both", expand=True, padx=25, pady=12)
        self.dynamic.append(panel)

        tk.Label(
            panel,
            text=f"Løbende analyse – {len(rows)} trials i alt",
            font=("Arial", 22, "bold"), bg="white"
        ).pack(pady=(0, 8))

        metrics = [
            ("Gennemsnitlig recall", "overall", True),
            ("Primacy recall (1–5)", "primacy", True),
            ("Middel recall (6–10)", "middle", True),
            ("Recency recall (11–15)", "recency", True),
            ("Primacy effect (1–5 minus 6–10)", "primacy_effect", False),
            ("Recency effect (11–15 minus 6–10)", "recency_effect", False),
        ]

        table = tk.Frame(panel, bg="white")
        table.pack()

        headers = ["Mål", "Gennemsnit", "95% konfidensinterval"]
        widths = [38, 16, 26]
        for c, (h, w) in enumerate(zip(headers, widths)):
            tk.Label(
                table, text=h, font=("Arial", 13, "bold"),
                bg="#e9e9e9", width=w, pady=5
            ).grid(row=0, column=c, padx=1, pady=1, sticky="nsew")

        values = {}
        cis = {}

        for i, (label, key, clamp) in enumerate(metrics, start=1):
            xs = [r[key] for r in rows]
            m = mean(xs)
            lo, hi = ci95(xs, clamp=clamp)
            values[key] = m
            cis[key] = (lo, hi)

            tk.Label(
                table, text=label, font=("Arial", 12),
                bg="white", width=widths[0], anchor="w", pady=4
            ).grid(row=i, column=0, sticky="nsew")
            tk.Label(
                table, text=pct(m), font=("Arial", 12),
                bg="white", width=widths[1]
            ).grid(row=i, column=1)
            tk.Label(
                table, text=ci_text(lo, hi), font=("Arial", 12),
                bg="white", width=widths[2]
            ).grid(row=i, column=2)

        # Søjlediagram med recall-rater og 95% CI.
        canvas = tk.Canvas(panel, width=900, height=300, bg="white", highlightthickness=0)
        canvas.pack(pady=(8, 2))

        x0, y0 = 80, 245
        top_y = 35
        chart_h = y0 - top_y
        canvas.create_line(x0, y0, 850, y0, width=2)
        canvas.create_line(x0, top_y, x0, y0, width=2)

        for p in [0, 25, 50, 75, 100]:
            y = y0 - (p / 100) * chart_h
            canvas.create_line(x0, y, 850, y, fill="#dddddd")
            canvas.create_text(48, y, text=f"{p}%", font=("Arial", 10))

        bars = [
            ("Overall", "overall"),
            ("Primacy", "primacy"),
            ("Middle", "middle"),
            ("Recency", "recency"),
        ]

        bar_w = 110
        gap = 65
        x = 120

        for label, key in bars:
            v = max(0, min(1, values[key]))
            lo, hi = cis[key]
            h = v * chart_h
            canvas.create_rectangle(x, y0 - h, x + bar_w, y0, fill="#8a8a8a", outline="#555555")
            canvas.create_text(x + bar_w/2, y0 - h - 12, text=pct(v), font=("Arial", 11, "bold"))
            canvas.create_text(x + bar_w/2, y0 + 20, text=label, font=("Arial", 11))

            if not math.isnan(lo) and not math.isnan(hi):
                cx = x + bar_w/2
                y_lo = y0 - max(0, min(1, lo)) * chart_h
                y_hi = y0 - max(0, min(1, hi)) * chart_h
                canvas.create_line(cx, y_hi, cx, y_lo, width=2)
                canvas.create_line(cx - 8, y_hi, cx + 8, y_hi, width=2)
                canvas.create_line(cx - 8, y_lo, cx + 8, y_lo, width=2)

            x += bar_w + gap

        tk.Label(
            panel,
            text=(
                "Konfidensintervallerne beregnes på trial-niveau. "
                "Primacy effect = recall(1–5) − recall(6–10). "
                "Recency effect = recall(11–15) − recall(6–10)."
            ),
            font=("Arial", 11), bg="white", wraplength=1100, justify="center"
        ).pack(pady=(2, 8))

        buttons = tk.Frame(panel, bg="white")
        buttons.pack()

        tk.Button(
            buttons, text="Næste trial",
            font=("Arial", 15), command=self.show_menu
        ).pack(side="left", padx=8)

        tk.Button(
            buttons, text="Luk program",
            font=("Arial", 15), command=self.quit_program
        ).pack(side="left", padx=8)

    def quit_program(self):
        self.root.destroy()

def main():
    root = tk.Tk()
    try:
        FreeRecallApp(root)
        root.mainloop()
    except Exception as e:
        messagebox.showerror("Fejl", str(e))
        root.destroy()

if __name__ == "__main__":
    main()
