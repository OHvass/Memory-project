# Free Recall – 4 forsøg + 95% CI

Denne version er identisk i forsøgslogik med den tidligere 4-betingelsesversion, men statistikskærmen viser nu også 95% konfidensintervaller for primacy- og recency-effekten i hver betingelse.

## Forsøg
- Standard: 15 billeder, 2,0 sek. pr. billede, recall med det samme.
- Hurtig: 15 billeder, 1,0 sek. pr. billede, recall med det samme.
- Plus/minus: 15 billeder, 2,0 sek. pr. billede, derefter 15 sek. regnestykker.
- Pause: 15 billeder, 2,0 sek. pr. billede, derefter 15 sek. almindelig pause.

## Statistik
For hver betingelse vises recall, primacy recall, middle recall, recency recall, primacy effect og recency effect.

- Primacy effect = recall position 1–5 minus recall position 6–10.
- Recency effect = recall position 11–15 minus recall position 6–10.
- 95% CI for hver effekt beregnes på trial-niveau. Der kræves mindst 2 trials i en betingelse før et CI kan beregnes.
- De relevante sammenligninger mellem betingelserne viser fortsat forskel og 95% CI for forskellen.
- Søjlediagrammet viser også CI-fejlstænger for primacy- og recency-effekterne, når mindst 2 trials findes.

## Start på Mac
Læg billedbanken i `images/`, åbn Terminal i projektmappen og kør:

```bash
python3 experiment.py
```

Hvis Pillow mangler:

```bash
python3 -m pip install Pillow
```
